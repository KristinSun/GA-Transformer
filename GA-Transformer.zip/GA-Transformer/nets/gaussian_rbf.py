import torch


@torch.jit.script
def gaussian(x, mean, std):
    pi = 3.14159
    a = (2*pi) ** 0.5
    return torch.exp(-0.5 * (((x - mean) / std) ** 2)) / (a * std)

#高斯径向基函数：num_basis 表示高斯径向基函数的数量，cutoff 表示截断半径。均值mean,标准差std,权重，偏差
# From Graphormer
class GaussianRadialBasisLayer(torch.nn.Module):
    def __init__(self, num_basis, cutoff):
        super().__init__()
        self.num_basis = num_basis
        self.cutoff = cutoff + 0.0
        self.mean   = torch.nn.Parameter(torch.zeros(1, self.num_basis))
        self.std    = torch.nn.Parameter(torch.zeros(1, self.num_basis))
        self.weight = torch.nn.Parameter(torch.ones(1, 1))
        self.bias = torch.nn.Parameter(torch.zeros(1, 1))
        
        self.std_init_max = 1.0
        self.std_init_min = 1.0 / self.num_basis
        self.mean_init_max = 1.0
        self.mean_init_min = 0
        torch.nn.init.uniform_(self.mean, self.mean_init_min, self.mean_init_max)
        torch.nn.init.uniform_(self.std, self.std_init_min, self.std_init_max)
        torch.nn.init.constant_(self.weight, 1)
        torch.nn.init.constant_(self.bias, 0)
        

    def forward(self, dist, node_atom=None, edge_src=None, edge_dst=None):
        x = dist / self.cutoff# 归一化距离
        x = x.unsqueeze(-1)# 维度扩展
        x = self.weight * x + self.bias# 线性变换
        x = x.expand(-1, self.num_basis)# 维度扩展
        mean = self.mean
        std = self.std.abs() + 1e-5#取绝对值并加上一个小的常数，避免除以零
        x = gaussian(x, mean, std) # 使用高斯函数进行变换
        return x
    
    
    def extra_repr(self):
        return 'mean_init_max={}, mean_init_min={}, std_init_max={}, std_init_min={}'.format(
            self.mean_init_max, self.mean_init_min, self.std_init_max, self.std_init_min)
    